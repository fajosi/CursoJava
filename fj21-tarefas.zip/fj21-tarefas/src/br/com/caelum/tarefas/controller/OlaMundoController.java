package br.com.caelum.tarefas.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller	
public class OlaMundoController {
	
	@RequestMapping("/olaMundoSpring")
	public String Execute() {
		System.out.println("Executando a lógica com Spring MVC");
		return "ok";
	}

	@RequestMapping("/index")
	public String index() {
		System.out.println("Executando a lógica com Spring MVC");
		return "index";
	}
}
